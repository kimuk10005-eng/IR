# -*- coding: utf-8 -*-
import numpy as np
import pickle
import tensorflow as tf
import os
import csv
import re
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Patch
from collections import Counter

plt.rcParams['font.family'] = 'Malgun Gothic'
plt.rcParams['axes.unicode_minus'] = False

SAVE_DIR = './kumoh_lstm_model_save'
ENCODER_PATH = os.path.join(SAVE_DIR, 'encoder.pkl')
WINDOW = 15
STEP = 5
SMOOTH_K = 5

FLOOR_THRESHOLDS = {
    '나무': {'gradient': 0.7, 'change_low': 6.0, 'change_strong': 18.0, 'plateau_mean': 9.0, 'plateau_med': 7.0, 'clear_mean': 2.8, 'sign_keep': 0.88, 'alpha': 0.030, 'ref_grad': 0.80, 'ref_band': 6.5, 'noise_ratio': 0.90, 'spike_ratio': 2.40, 'local_change': 4.0, 'keep_mean_local': 2.0, 'keep_area_local': 30.0, 'release_mean_local': 1.0, 'release_area_local': 16.0, 'memory_windows': 2},
    '황대': {'gradient': 0.6, 'change_low': 5.0, 'change_strong': 15.0, 'plateau_mean': 7.0, 'plateau_med': 6.0, 'clear_mean': 2.3, 'sign_keep': 0.88, 'alpha': 0.028, 'ref_grad': 0.75, 'ref_band': 6.0, 'noise_ratio': 0.82, 'spike_ratio': 2.20, 'local_change': 3.0, 'keep_mean_local': 1.8, 'keep_area_local': 28.0, 'release_mean_local': 1.0, 'release_area_local': 16.0, 'memory_windows': 2},
    '회대': {'gradient': 0.7, 'change_low': 6.0, 'change_strong': 18.0, 'plateau_mean': 9.0, 'plateau_med': 7.0, 'clear_mean': 2.8, 'sign_keep': 0.89, 'alpha': 0.026, 'ref_grad': 0.75, 'ref_band': 6.0, 'noise_ratio': 0.78, 'spike_ratio': 2.05, 'local_change': 3.0, 'keep_mean_local': 2.0, 'keep_area_local': 32.0, 'release_mean_local': 1.2, 'release_area_local': 18.0, 'memory_windows': 2},
    '검대': {'gradient': 0.7, 'change_low': 6.0, 'change_strong': 18.0, 'plateau_mean': 9.0, 'plateau_med': 7.0, 'clear_mean': 2.8, 'sign_keep': 0.89, 'alpha': 0.026, 'ref_grad': 0.75, 'ref_band': 6.0, 'noise_ratio': 0.78, 'spike_ratio': 2.05, 'local_change': 3.0, 'keep_mean_local': 2.6, 'keep_area_local': 38.0, 'release_mean_local': 1.5, 'release_area_local': 22.0, 'memory_windows': 2},
    '그마': {'gradient': 0.7, 'change_low': 6.0, 'change_strong': 18.0, 'plateau_mean': 9.0, 'plateau_med': 7.0, 'clear_mean': 2.8, 'sign_keep': 0.89, 'alpha': 0.026, 'ref_grad': 0.75, 'ref_band': 6.0, 'noise_ratio': 0.78, 'spike_ratio': 2.05, 'local_change': 3.0, 'keep_mean_local': 2.0, 'keep_area_local': 32.0, 'release_mean_local': 1.2, 'release_area_local': 18.0, 'memory_windows': 2},
    '207회바': {'gradient': 0.7, 'change_low': 6.0, 'change_strong': 18.0, 'plateau_mean': 9.0, 'plateau_med': 7.0, 'clear_mean': 2.8, 'sign_keep': 0.89, 'alpha': 0.026, 'ref_grad': 0.75, 'ref_band': 6.0, 'noise_ratio': 0.78, 'spike_ratio': 2.05, 'local_change': 3.0, 'keep_mean_local': 2.0, 'keep_area_local': 32.0, 'release_mean_local': 1.2, 'release_area_local': 18.0, 'memory_windows': 2},
    '흰책상': {'gradient': 0.7, 'change_low': 6.0, 'change_strong': 18.0, 'plateau_mean': 9.0, 'plateau_med': 7.0, 'clear_mean': 2.8, 'sign_keep': 0.89, 'alpha': 0.026, 'ref_grad': 0.75, 'ref_band': 6.0, 'noise_ratio': 0.78, 'spike_ratio': 2.05, 'local_change': 3.0, 'keep_mean_local': 1.8, 'keep_area_local': 28.0, 'release_mean_local': 1.0, 'release_area_local': 16.0, 'memory_windows': 2},
    '나타': {'gradient': 0.8, 'change_low': 6.5, 'change_strong': 19.0, 'plateau_mean': 10.0, 'plateau_med': 8.0, 'clear_mean': 3.0, 'sign_keep': 0.90, 'alpha': 0.020, 'ref_grad': 0.65, 'ref_band': 5.0, 'noise_ratio': 0.68, 'spike_ratio': 1.85, 'local_change': 3.0, 'keep_mean_local': 1.8, 'keep_area_local': 28.0, 'release_mean_local': 1.0, 'release_area_local': 16.0, 'memory_windows': 2},
    '회타': {'gradient': 0.8, 'change_low': 6.5, 'change_strong': 19.0, 'plateau_mean': 10.0, 'plateau_med': 8.0, 'clear_mean': 3.0, 'sign_keep': 0.90, 'alpha': 0.020, 'ref_grad': 0.65, 'ref_band': 5.0, 'noise_ratio': 0.68, 'spike_ratio': 1.85, 'local_change': 3.0, 'keep_mean_local': 2.0, 'keep_area_local': 32.0, 'release_mean_local': 1.2, 'release_area_local': 18.0, 'memory_windows': 2},
}
FLOOR_MODELS = {'나무': os.path.join(SAVE_DIR, 'model_나무.keras'),'황대': os.path.join(SAVE_DIR, 'model_황대.keras'),'회대': os.path.join(SAVE_DIR, 'model_회대.keras'),'검대': os.path.join(SAVE_DIR, 'model_검대.keras'),'그마': os.path.join(SAVE_DIR, 'model_그마.keras'),'207회바': os.path.join(SAVE_DIR, 'model_207회바.keras'),'흰책상': os.path.join(SAVE_DIR, 'model_흰책상.keras'),'나타': os.path.join(SAVE_DIR, 'model_나타.keras'),'회타': os.path.join(SAVE_DIR, 'model_회타.keras')}
FLOOR_ALIASES = {'나무': ['나무', 'wood', '나'],'황대': ['황대', '황색대리석', '황색', 'yellow', '황'],'회대': ['회대', '회색대리석', '회색', 'gray', '회'],'검대': ['검대', '검정색대리석', '검정', 'black', '검'],'그마': ['그마', 'greymarble'],'207회바': ['회바', '207', '207greyfloor', 'greyfloor'],'흰책상': ['흰책상', 'white', 'whitedesk'],'나타': ['나타'],'회타': ['회타']}
REVERSE_DIRECTION_FLOORS = {'검대'}
LOCAL_REF_BACK = 20
LOCAL_REF_GUARD = 3

try:
    encoder = pickle.load(open(ENCODER_PATH, 'rb'))
    classes = encoder.classes_
except Exception as e:
    print(f"인코더 로드 실패: {e}")
    raise SystemExit

models = {}
for floor, path in FLOOR_MODELS.items():
    if os.path.exists(path):
        try:
            models[floor] = tf.keras.models.load_model(path)
            print(f"모델 로드 완료: {floor}")
        except Exception as e:
            print(f"{floor} 모델 로드 실패: {e}")
    else:
        print(f"모델 파일 없음: {path}")

def find_floor_type(text):
    text = text.lower().strip()
    for floor, aliases in FLOOR_ALIASES.items():
        if text in [a.lower() for a in aliases]:
            return floor
    return None

def _to_float(x):
    try:
        x = str(x).strip()
        return float(x) if x != '' else None
    except Exception:
        return None

def smooth_signal(x, k=SMOOTH_K):
    if len(x) == 0:
        return x
    kernel = np.ones(k, dtype=np.float32) / float(k)
    return np.convolve(np.asarray(x, dtype=np.float32), kernel, mode='same')

def remove_spikes(signal, k=3.0, local=5):
    sig = np.array(signal, dtype=np.float32).copy()
    if len(sig) < 3:
        return sig
    for i in range(1, len(sig) - 1):
        left = max(0, i - local)
        right = min(len(sig), i + local + 1)
        local_med = float(np.median(sig[left:right]))
        local_std = float(np.std(sig[left:right])) + 1e-6
        if abs(float(sig[i]) - local_med) > k * local_std and abs(float(sig[i]) - float(sig[i-1])) > 1.2 * local_std and abs(float(sig[i]) - float(sig[i+1])) > 1.2 * local_std:
            sig[i] = np.float32(0.5 * (sig[i - 1] + sig[i + 1]))
    return sig

def compute_noise_metrics(diff_w, smooth_w):
    mean_abs_diff = float(np.mean(np.abs(diff_w))) + 1e-6
    noise_ratio = float(np.std(diff_w) / mean_abs_diff)
    spike_ratio = float((np.max(smooth_w) - np.min(smooth_w)) / mean_abs_diff)
    return noise_ratio, spike_ratio

def read_csv_with_fixed_baseline(fp):
    encodings = ['utf-8-sig', 'utf-8', 'cp949', 'euc-kr']
    def parse_new_format(lines):
        baseline_values = []
        row_bases = []
        data_points = []
        timestamps = []
        reader = csv.DictReader(lines)
        fields = [str(name).strip() for name in (reader.fieldnames or [])]
        if 'record_type' not in fields:
            return None, None, None, None
        for row in reader:
            record_type = str(row.get('record_type', '')).strip().lower()
            baseline_raw = _to_float(row.get('baseline_raw', ''))
            base_raw = _to_float(row.get('base_raw', ''))
            current_raw = _to_float(row.get('current_raw', ''))
            raw_data = str(row.get('raw_data', '')).strip()
            if record_type == 'baseline':
                if baseline_raw is not None:
                    baseline_values.append(baseline_raw)
                elif base_raw is not None:
                    baseline_values.append(base_raw)
                continue
            if record_type == 'data':
                if current_raw is None and raw_data:
                    m = re.search(r'CurrentRaw\s*=?\s*([0-9.+-]+)', raw_data)
                    if m:
                        current_raw = _to_float(m.group(1))
                    m2 = re.search(r'BaseRaw\s*=?\s*([0-9.+-]+)', raw_data)
                    if base_raw is None and m2:
                        base_raw = _to_float(m2.group(1))
                if current_raw is not None:
                    data_points.append(current_raw)
                    m = re.search(r'Time\s*=\s*([0-9.]+)s', raw_data)
                    timestamps.append(m.group(1) + 's' if m else str(len(data_points) - 1))
                if base_raw is not None:
                    row_bases.append(base_raw)
        if len(data_points) < WINDOW:
            return None, None, None, None
        if baseline_values:
            base = float(np.mean(baseline_values))
        elif row_bases:
            base = float(np.mean(row_bases))
        else:
            return None, None, None, None
        buffer = np.array(data_points, dtype=np.float32)
        changes = np.abs(buffer - base).astype(np.float32)
        return base, buffer, changes, timestamps

    def parse_old_format(lines):
        baseline_values = []
        row_bases = []
        data_points = []
        timestamps = []
        final_base = None
        for raw_line in lines:
            line = str(raw_line).strip()
            if not line:
                continue
            parts = [p.strip() for p in line.split(',')]
            if not parts:
                continue
            if parts[0].startswith('Collecting baseline'):
                if len(parts) >= 3 and parts[1] == 'RawAvg':
                    v = _to_float(parts[2])
                    if v is not None:
                        baseline_values.append(v)
                continue
            if len(parts) >= 5 and parts[:4] == ['Final', 'Base', 'Raw', 'Average']:
                v = _to_float(parts[4])
                if v is not None:
                    final_base = v
                continue
            if parts[0] == 'Time':
                time_val = parts[1] if len(parts) >= 2 else None
                base_raw = None
                current_raw = None
                for i in range(len(parts) - 1):
                    if parts[i] == 'BaseRaw':
                        base_raw = _to_float(parts[i + 1])
                    elif parts[i] == 'CurrentRaw':
                        current_raw = _to_float(parts[i + 1])
                if current_raw is not None:
                    data_points.append(current_raw)
                    timestamps.append(time_val if time_val else str(len(data_points) - 1))
                if base_raw is not None:
                    row_bases.append(base_raw)
        if len(data_points) < WINDOW:
            return None, None, None, None
        if final_base is not None:
            base = float(final_base)
        elif baseline_values:
            base = float(np.mean(baseline_values))
        elif row_bases:
            base = float(np.mean(row_bases))
        else:
            return None, None, None, None
        buffer = np.array(data_points, dtype=np.float32)
        changes = np.abs(buffer - base).astype(np.float32)
        return base, buffer, changes, timestamps

    for enc in encodings:
        try:
            with open(fp, 'r', encoding=enc, errors='ignore', newline='') as f:
                lines = f.readlines()
            result = parse_new_format(lines)
            if result[0] is not None:
                return result
            result = parse_old_format(lines)
            if result[0] is not None:
                return result
        except Exception:
            continue
    return None, None, None, None

def build_recent_floor_reference(signal, baseline, floor_type):
    params = FLOOR_THRESHOLDS.get(floor_type, FLOOR_THRESHOLDS['회대'])
    sig = smooth_signal(remove_spikes(signal))
    grad = np.gradient(sig)
    ref = np.empty_like(sig)
    ref[0] = baseline
    alpha = params.get('alpha', 0.03)
    ref_grad = params.get('ref_grad', 0.8)
    ref_band = params.get('ref_band', 6.5)
    for i in range(1, len(sig)):
        stable_grad = abs(grad[i]) < ref_grad
        close_to_ref = abs(sig[i] - ref[i - 1]) < ref_band
        if stable_grad and close_to_ref:
            ref[i] = (1.0 - alpha) * ref[i - 1] + alpha * sig[i]
        else:
            ref[i] = ref[i - 1]
    return sig, grad, ref

def compute_local_reference(signal, start_idx, global_base):
    ref_end = max(0, start_idx - LOCAL_REF_GUARD)
    ref_start = max(0, ref_end - LOCAL_REF_BACK)
    ref = signal[ref_start:ref_end]
    if len(ref) < 5:
        return float(global_base)
    ref_smooth = smooth_signal(ref, k=min(5, len(ref)))
    ref_grad = np.abs(np.gradient(ref_smooth)) if len(ref_smooth) >= 2 else np.zeros_like(ref_smooth)
    thr = np.percentile(ref_grad, 70) if len(ref_grad) > 0 else 0.0
    stable_ref = ref_smooth[ref_grad <= thr]
    if len(stable_ref) < 3:
        stable_ref = ref_smooth
    return float(np.mean(stable_ref))

def create_window(full_signal, start_idx, baseline, floor_type):
    if start_idx + WINDOW > len(full_signal):
        return None
    sig = full_signal[start_idx:start_idx + WINDOW]
    norm_sig = (sig - sig.mean()) / (sig.std() + 1e-8)
    deriv1 = np.diff(norm_sig)
    deriv1 = np.convolve(deriv1, np.ones(3) / 3, 'same')
    deriv1 = np.pad(deriv1, (1, 0))
    deriv2 = np.diff(deriv1)
    deriv2 = np.pad(deriv2, (1, 0))
    base_eff = baseline if len(full_signal) < 20 else 0.7 * baseline + 0.3 * np.mean(full_signal[:20])
    context_start = max(0, start_idx - 5)
    context_end = min(len(full_signal), start_idx + WINDOW + 5)
    recent_mean = np.mean(full_signal[context_start:context_end])
    change_raw = base_eff - recent_mean if floor_type in REVERSE_DIRECTION_FLOORS else recent_mean - base_eff
    direction = np.clip(change_raw / 300.0, -1.0, 1.0)
    direction_channel = np.full((WINDOW,), direction)
    window = np.stack([norm_sig, deriv1, deriv2, direction_channel])
    return window[np.newaxis, :, :]

def get_best_non_floor_label(pred):
    floor_idx = np.where(classes == '바닥')[0][0] if '바닥' in classes else -1
    temp = pred.copy()
    if floor_idx >= 0:
        temp[floor_idx] = -1.0
    idx = int(np.argmax(temp))
    return classes[idx], float(max(temp[idx] * 100.0, 0.0))

def apply_light_memory_postprocess(predictions, floor_type):
    if not predictions:
        return predictions
    params = FLOOR_THRESHOLDS[floor_type]
    memory = 0
    release_count = 0
    for p in predictions:
        is_liquid_now = p['label'] != '바닥'
        keep_cond = (p['mean_local_change'] >= params['keep_mean_local'] and p['area_local_change'] >= params['keep_area_local'])
        release_cond = (p['mean_local_change'] < params['release_mean_local'] and p['area_local_change'] < params['release_area_local'])
        if is_liquid_now:
            memory = params['memory_windows']
            release_count = 0
            continue
        if memory > 0 and keep_cond:
            p['label'] = p['fallback_liquid_label']
            p['prob'] = max(p['prob'], 70.0)
            memory -= 1
            continue
        if release_cond:
            release_count += 1
        else:
            release_count = 0
        if release_count >= 2:
            memory = 0
    return predictions

def predict(buffer, changes, baseline, floor_type, model):
    predictions = []
    max_start = len(buffer) - WINDOW
    if max_start < 0:
        return []
    params = FLOOR_THRESHOLDS[floor_type]
    clean_buffer = remove_spikes(buffer)
    changes = np.abs(clean_buffer - baseline).astype(np.float32)
    sig_smooth, change_gradient, floor_ref = build_recent_floor_reference(clean_buffer, baseline, floor_type)
    floor_idx = np.where(classes == '바닥')[0][0] if '바닥' in classes else -1

    for start_idx in range(0, max_start + 1, STEP):
        end_idx = start_idx + WINDOW
        window = create_window(clean_buffer, start_idx, baseline, floor_type)
        if window is None:
            continue
        smooth_w = sig_smooth[start_idx:end_idx]
        ref_w = floor_ref[start_idx:end_idx]
        diff_w = smooth_w - ref_w
        window_changes = changes[start_idx:end_idx]
        window_gradient = change_gradient[start_idx:end_idx]
        local_ref = compute_local_reference(sig_smooth, start_idx, baseline)
        local_diff = smooth_w - local_ref
        local_abs = np.abs(local_diff)
        mean_local_change = float(np.mean(local_abs))
        max_local_change = float(np.max(local_abs))
        area_local_change = float(np.sum(local_abs))
        avg_change = float(np.mean(window_changes))
        max_change = float(np.max(window_changes))
        max_gradient = float(np.max(np.abs(window_gradient)))
        mean_floor_diff = float(np.mean(np.abs(diff_w)))
        median_floor_diff = float(np.abs(np.median(diff_w)))
        sign_consistency = float(max(np.mean(diff_w >= 0), np.mean(diff_w <= 0)))
        noise_ratio, spike_ratio = compute_noise_metrics(diff_w, smooth_w)
        if model:
            pred = model.predict(np.transpose(window, (0, 2, 1)), verbose=0)[0]
        else:
            pred = np.zeros(len(classes), dtype=np.float32)
            pred[floor_idx] = 1.0
        orig_idx = int(np.argmax(pred))
        orig_label = classes[orig_idx]
        orig_prob = float(pred[orig_idx] * 100.0)
        fallback_liquid, fallback_prob = get_best_non_floor_label(pred)
        strong_global = max_change >= params['change_strong']
        simple_global = max_change >= params['change_low']
        plateau_liquid = (
            max_change >= params['change_low'] and
            mean_floor_diff >= params['plateau_mean'] and
            median_floor_diff >= params['plateau_med'] and
            sign_consistency >= params['sign_keep'] and
            noise_ratio <= params.get('noise_ratio', 0.8) and
            spike_ratio <= params.get('spike_ratio', 2.0)
        )
        local_keep = (mean_local_change >= params['keep_mean_local'] and area_local_change >= params['keep_area_local'])
        calm_floor = (avg_change < params['change_low'] * 0.70 and mean_floor_diff < params['clear_mean'] and max_gradient < params['gradient'] * 0.95)

        if strong_global:
            final_label = orig_label if orig_label != '바닥' else fallback_liquid
            final_prob = max(orig_prob, fallback_prob, 84.0)
        elif simple_global and orig_label != '바닥' and orig_prob >= 62.0:
            final_label = orig_label
            final_prob = max(orig_prob, 74.0)
        elif simple_global and fallback_prob >= 45.0:
            final_label = fallback_liquid
            final_prob = max(fallback_prob, 66.0)
        elif plateau_liquid and local_keep and fallback_prob >= 40.0:
            final_label = fallback_liquid
            final_prob = max(fallback_prob, 62.0)
        elif calm_floor:
            final_label = '바닥'
            final_prob = 93.0
        else:
            final_label = orig_label
            final_prob = orig_prob

        predictions.append({
            'start': start_idx, 'end': end_idx, 'label': final_label, 'prob': final_prob,
            'orig_label': orig_label, 'orig_prob': orig_prob, 'max_change': max_change,
            'avg_change': avg_change, 'mean_local_change': mean_local_change,
            'max_local_change': max_local_change, 'area_local_change': area_local_change,
            'max_gradient': max_gradient, 'mean_floor_diff': mean_floor_diff,
            'local_ref': local_ref, 'fallback_liquid_label': fallback_liquid,
        })
    return apply_light_memory_postprocess(predictions, floor_type)

def visualize(predictions, buffer, global_changes, baseline, floor_type):
    FLOOR_COLOR = '#E8E8E8'
    LIQUID_COLOR = '#5C2F0F'
    fig = plt.figure(figsize=(17, 11))
    gs = fig.add_gridspec(4, 1, height_ratios=[2.2, 1.6, 1, 1])
    ax1 = fig.add_subplot(gs[0])
    ax1_twin = ax1.twinx()
    ax1.plot(buffer, 'b-', lw=2, label='CurrentRaw')
    ax1.axhline(baseline, color='green', ls='--', lw=2, label=f'Base: {baseline:.1f}')
    ax1_twin.plot(global_changes, 'r:', alpha=0.7, lw=1.8, label='Global Change')
    for r in predictions:
        color = FLOOR_COLOR if r['label'] == '바닥' else LIQUID_COLOR
        alpha = 0.25 if r['label'] == '바닥' else 0.5
        ax1.axvspan(r['start'], min(r['end'], len(buffer)), color=color, alpha=alpha)
    ax1.set_title(f'{floor_type} 바닥 - LSTM 실시간 액체 감지 결과', fontsize=16, fontweight='bold')
    ax1.legend(loc='upper left')
    ax1_twin.legend(loc='upper right')
    ax1.grid(alpha=0.3)

    ax2 = fig.add_subplot(gs[1])
    bar_colors = [FLOOR_COLOR if r['label'] == '바닥' else LIQUID_COLOR for r in predictions]
    ax2.bar(range(len(predictions)), [r['prob'] for r in predictions], color=bar_colors, alpha=0.85, edgecolor='black', linewidth=0.5)
    ax2.set_ylim(0, 105)
    ax2.set_title('신뢰도')
    ax2.grid(alpha=0.3, axis='y')

    ax3 = fig.add_subplot(gs[2])
    ax3.plot([r['max_gradient'] for r in predictions], 'purple', alpha=0.8, label='Gradient (최대 변화율)')
    ax3.plot([r['mean_local_change'] for r in predictions], color='orange', alpha=0.8, label='Mean Local Change')
    ax3.axhline(FLOOR_THRESHOLDS[floor_type]['gradient'], color='red', ls='--', lw=2, label='Gradient 기준')
    ax3.legend(loc='upper right')
    ax3.set_title('Gradient / Local Change')
    ax3.grid(alpha=0.3)

    ax4 = fig.add_subplot(gs[3])
    for i, r in enumerate(predictions):
        color = FLOOR_COLOR if r['label'] == '바닥' else LIQUID_COLOR
        ax4.add_patch(Rectangle((i, 0), 1, 1, facecolor=color, edgecolor='black', lw=1.2))
        text_color = 'black' if r['label'] == '바닥' else 'white'
        ax4.text(i + 0.5, 0.5, '바' if r['label'] == '바닥' else '액', ha='center', va='center', fontsize=9, color=text_color, fontweight='bold')
    ax4.set_xlim(0, len(predictions))
    ax4.set_ylim(0, 1)
    ax4.set_yticks([])
    ax4.set_title('예측 시퀀스')
    legend_handles = [Patch(facecolor=FLOOR_COLOR, edgecolor='black', label='바닥'), Patch(facecolor=LIQUID_COLOR, edgecolor='black', label='액체')]
    ax4.legend(handles=legend_handles, loc='upper center', bbox_to_anchor=(0.5, -0.15), ncol=2, fontsize=11)
    plt.tight_layout()
    plt.show()

def summarize_predictions(predictions):
    labels = [p['label'] for p in predictions if p['label'] != '바닥']
    if not labels:
        print('\n최종 요약: 액체 이벤트를 확실히 찾지 못했습니다.')
        return
    cnt = Counter(labels)
    label, n = cnt.most_common(1)[0]
    print(f'\n최종 요약: 가장 많이 나온 액체 = {label} ({n} windows)')

def main():
    print('\n' + '=' * 80)
    print('LSTM 액체 감지 예측기 - 3-4 (2-4 플로우 복구)'.center(80))
    print('=' * 80 + '\n')
    while True:
        print('지원 바닥:', ', '.join(models.keys()))
        print('종료: q')
        cmd = input('\n바닥 타입 ▶ ').strip()
        if cmd.lower() in ['q', 'quit', 'exit', '']:
            print('종료합니다.')
            break
        floor_type = find_floor_type(cmd)
        if not floor_type:
            print('지원되지 않는 바닥 타입입니다.')
            continue
        if floor_type not in models:
            print(f'해당 바닥 모델이 없습니다: {floor_type}')
            continue
        csv_path = input('CSV 경로 ▶ ').strip().strip('"')
        if not os.path.exists(csv_path):
            print('파일을 찾을 수 없습니다.')
            continue
        baseline, buffer, changes, _timestamps = read_csv_with_fixed_baseline(csv_path)
        if baseline is None:
            print('CSV를 읽지 못했습니다.')
            continue
        preds = predict(buffer, changes, baseline, floor_type, models[floor_type])
        for i, p in enumerate(preds[:25], start=1):
            print(f"[{i:02d}] {p['start']:4d}-{p['end']:4d} | {p['label']:>4s} | prob={p['prob']:5.1f} | maxchg={p['max_change']:6.2f} | mlocal={p['mean_local_change']:5.2f} | grad={p['max_gradient']:5.2f}")
        summarize_predictions(preds)
        visualize(preds, buffer, changes, baseline, floor_type)

if __name__ == '__main__':
    main()
